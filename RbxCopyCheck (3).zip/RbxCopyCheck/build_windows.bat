@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo ============================================
echo  RbxCopyCheck.exe 만들기 (더블클릭 한 번이면 끝)
echo ============================================

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY ( where python >nul 2>nul && set "PY=python" )

if not defined PY (
  echo.
  echo [1/3] Python이 없어서 자동 설치합니다... ^(winget 사용, 1~2분^)
  winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
  if errorlevel 1 (
    echo.
    echo 자동 설치에 실패했습니다. https://www.python.org/downloads/ 에서
    echo Python을 설치^(Add python.exe to PATH 체크^)한 뒤 이 파일을 다시 실행하세요.
    pause & exit /b 1
  )
  echo.
  echo Python 설치 완료! 이 창을 닫고 build_windows.bat 을 한 번 더 실행해 주세요.
  pause & exit /b 0
)

echo.
echo [2/3] 빌드 도구 설치 중...
%PY% -m pip install --upgrade pip pyinstaller
if errorlevel 1 ( echo 도구 설치 실패 & pause & exit /b 1 )

echo.
echo [3/3] exe 만드는 중... ^(1~2분^)
%PY% -m PyInstaller --noconfirm --onefile --windowed --name RbxCopyCheck rbx_copycheck_app.py
if errorlevel 1 ( echo 빌드 실패 & pause & exit /b 1 )

copy /y "dist\RbxCopyCheck.exe" "RbxCopyCheck.exe" >nul
echo.
echo ============================================
echo  완료!  이 폴더의 RbxCopyCheck.exe 를 더블클릭하세요.
echo ============================================
start "" "RbxCopyCheck.exe"
pause
