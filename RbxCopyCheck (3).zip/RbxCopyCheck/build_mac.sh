#!/bin/bash
# macOS 터미널에서: chmod +x build_mac.sh && ./build_mac.sh
# 사전 준비: python.org 의 Python 3.10+ 설치 (tkinter 포함 버전 권장)
set -e
python3 -m pip install --upgrade pip pyinstaller
python3 -m PyInstaller --noconfirm --windowed --name RbxCopyCheck rbx_copycheck_app.py
cd dist && zip -r RbxCopyCheck-mac.zip RbxCopyCheck.app && cd ..
echo "완료: dist/RbxCopyCheck.app  (배포용: dist/RbxCopyCheck-mac.zip)"
