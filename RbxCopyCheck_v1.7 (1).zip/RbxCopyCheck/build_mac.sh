#!/bin/bash
# macOS 터미널에서: chmod +x build_mac.sh && ./build_mac.sh
# 사전 준비: python.org 의 Python 3.10+ 설치 (tkinter 포함 버전 권장)
set -e
python3 -m pip install --upgrade pip pyinstaller pillow pywebview
python3 -m PyInstaller --noconfirm --windowed --collect-submodules webview --name RbxCopyCheck_v1.7 rbx_copycheck_app.py
cd dist && zip -r RbxCopyCheck_v1.7-mac.zip RbxCopyCheck_v1.7.app && cd ..
echo "완료: dist/RbxCopyCheck_v1.7.app  (배포용: dist/RbxCopyCheck_v1.7-mac.zip)"
